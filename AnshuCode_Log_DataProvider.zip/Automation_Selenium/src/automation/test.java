package automation;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.AfterTest;
import java.io.File;
import java.lang.reflect.Method;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;



public class test {
	
   public Logger logger = Logger.getLogger(test.class);
  
	//public final Logger = LogFactory.getLogger(getClass());
  @Test(dataProvider="data")
  public void tc_1_automated(String keyword) {	 
	 ProfilesIni profile = new ProfilesIni();
	 FirefoxProfile ffprofile = profile.getProfile("default");
	 ffprofile.setEnableNativeEvents(true);
		WebDriver driver = new FirefoxDriver(ffprofile);		   
		driver.get("https://www.amazon.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys(keyword);
		driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input")).click();
		//String ActualValue = driver.findElement(By.xpath(".//*[@id='bcKwText']/span")).getText();
		String ActualValue = driver.findElement(By.cssSelector(".a-color-state.a-text-bold")).getText();
		String expectedValue=keyword;
		//String expectedValue=driver.findElement(By.xpath(".//*[@id='bcKwText']/span")).getText();
		ActualValue  = ActualValue.replace("\"", "");
		System.out.println("Actual value:"+ActualValue );
		System.out.println("Expected value:"+expectedValue);
		Assert.assertTrue(expectedValue.equals(ActualValue),"Values matched");
		logger.info("Asserting first test case here");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.quit();
  }
  
  @DataProvider(name="data")
  public static Object[][] getData(Method name) {
	  Object[][] obj =null;;
	  if(name.getName().equalsIgnoreCase("tc_1_automated")){  
     obj =new Object[3][1];
     obj[0][0]="ipad";
     obj[1][0]="amazon echo";
     obj[2][0]="apple watch";}
  
  if(name.getName().equalsIgnoreCase("tc_2_automated"))
  {
	  obj =new Object[1][1];
	     obj[0][0]="Dell laptops";
  }
     return obj;
  }

  @Test(dataProvider="data")
  public void tc_2_automated(String keyword) { 
	  ProfilesIni profile = new ProfilesIni();
	  FirefoxProfile ffprofile = profile.getProfile("default");
	  ffprofile.setEnableNativeEvents(true);
	  WebDriver driver = new FirefoxDriver(ffprofile);	
	  driver.get("https://www.amazon.com/");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  driver.findElement(By.id("twotabsearchtextbox")).sendKeys(keyword);
	  driver.findElement(By.xpath(".//*[@id='nav-search']/form/div[2]/div/input")).click();
	  List<WebElement> search = driver.findElements(By.xpath(".//*[@id='result_0']/div/div/div/div[2]/div[3]/div[1]/a/h2"));
	  String ActualValue=search.get(0).getText();
      search.get(0).click();
     // System.out.print("The size is"+ search.size());
      driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  JavascriptExecutor jse = (JavascriptExecutor)driver;
      jse.executeScript("window.scrollBy(0,1000)", "");
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	 String expectedValue =driver.findElement(By.xpath(".//*[@id='title']")).getText();
	logger.info("Asserting second test case here");
      Assert.assertTrue(expectedValue.equals(ActualValue),"Values matched");
      driver.quit();
  }
  @org.testng.annotations.BeforeClass
  public void BeforeClass() {
	 
	  logger.info("******--This is before class method--******");	
	  
  }
  
  @AfterClass
  public void afterClass() {
	  logger.info("******--This is after class method--******");	
  }

 

}
